package com.example.macstudent.catalog;

import android.content.res.Resources;

import java.util.List;
import java.util.Vector;

/**
 * Created by macstudent on 2017-08-14.
 */

public class ShoppingCartHelper {

    public static final String PRODUCT_INDEX = "PRODUCT_INDEX";

    private static List<Product> catalog;
    private static List<Product> cart;

    public static List<Product> getCatalog(Resources res){
        if(catalog == null) {
            catalog = new Vector<Product>();
            catalog.add(new Product("Iphone 7", res
                    .getDrawable(R.drawable.ip7),
                    "Screen: 4.7 v" +
                            "Camera: 12 MP " +
                            "Ram: 2GB " +
                            "Battery Power: 1960mAh", 789.99));
            catalog.add(new Product("Samsung Galaxy S8", res
                    .getDrawable(R.drawable.galaxys8),
                    "Screen: 5.8 v" +
                            "Camera: 12 MP " +
                            "Ram: 4GB " +
                            "Battery Power: 3000mAh", 949.99));
            catalog.add(new Product("Lg G6", res
                    .getDrawable(R.drawable.lgg6),
                    "Screen: 5.7 v" +
                            "Camera: 13 MP " +
                            "Ram: 4GB " +
                            "Battery Power: 3300mAh", 549.99));
            catalog.add(new Product("Iphone 6", res
                    .getDrawable(R.drawable.ip6),
                    "Screen: 4.7 v" +
                            "Camera: 8 MP " +
                            "Ram: 1GB " +
                            "Battery Power: 1810mAh", 599.99));
            catalog.add(new Product("Lg G5", res
                    .getDrawable(R.drawable.lgg5),
                    "Screen: 5.3 v" +
                            "Camera: 16 MP " +
                            "Ram: 4GB " +
                            "Battery Power: 2800mAh", 489.99));
            catalog.add(new Product("Samsung Galaxy S7", res
                    .getDrawable(R.drawable.galaxys7),
                    "Screen: 5.1 v" +
                            "Camera: 12 MP " +
                            "Ram: 4GB " +
                            "Battery Power: 3000mAh", 399.99));
        }

        return catalog;
    }

    public static List<Product> getCart() {
        if(cart == null) {
            cart = new Vector<Product>();
        }

        return cart;
    }

}
