package com.example.macstudent.catalog;

import android.app.Activity;
import android.os.Bundle;

/**
 * Created by macstudent on 2017-08-14.
 */

public class checkout  extends Activity{

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.checkout);

    }
}
